<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'local' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'MNCN6ejhMQPJ4OABVEGgMTqLV+Zm9zqqAthx3Ii6KyYJ+N3cPSL1gtx7d4DdCb58zRn7lMKGRzfRBnhoi4DZ8g==');
define('SECURE_AUTH_KEY',  'gBAa+40yLeLe14zQ2WG8aCfxf8XABkdvAHahTJ0qWYD+r1sC9kAfr/29PCpR+G9t78gC4lDQrHQ6CxJ3Fd+3hg==');
define('LOGGED_IN_KEY',    '2ynp75jLpNHFtheggZuEVA8eGb3SIdxXjpUZx7FNgEIagmIXmOfR3I/AaneRLfDPpCtPkxLLolUxtZDiWvxowA==');
define('NONCE_KEY',        'g4eKPX2p4JGmHAo45muY+XhR1Lba7isgz8NLH8HKXVLTgV4QPVVuZqSHuP0/3zmIGWGx67U74WSU/nXyoAA7bQ==');
define('AUTH_SALT',        'q+Oqmv06mR8YK4YVpIWsSElyvigFEVau0XlIGJR2zjFEI/BmaEZeo7WrhC6bO0Vl110y0Dc6yYhJTjfvXEiTRQ==');
define('SECURE_AUTH_SALT', '7GoVsLXkGewMm8Z9kkjQW9cOR/sq7vr4VrKPnnP7R7OKdruNs8RVMO/KCC0PHVy7YsRya+OLvt6nRw4P7YM7Tg==');
define('LOGGED_IN_SALT',   'b0+NXlES7oIZ2cocD6xLkRFvCdvc6wLpfNh022lVqlzxeY7B+dEu6mYkBWbBRXDEkNgGV1bQxYeoCOy4tI37EA==');
define('NONCE_SALT',       'PmmRG9QuHVOZG6ulyeW8aaLLwRJHiDnuKlxHVYIqG/33P4pUpsMXwQOLYCMbV1rZChK4S+3awMbvwbwI6SkoBA==');

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';




/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
