<!DOCTYPE html>
<html lang="en">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
  <title></title>
  <link rel="stylesheet" href="styles/mybasestyle.css"/>
<link rel="stylesheet" href="styles/socialmedia-style.css" type="text/css" />



<meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

</head>

<body bgcolor="#e2b808">

<section class="header">
	<div class="logo"> <img src= style="width:100%;"/> </div>
	<div class="pageMenu"> 
	<!-- Site navigation menu -->

	

	</div>


</section>

<div class="navimg"></div>

<div class="pageheading">  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;Thankyou For  Submitting Form: </div>

<section class="Main-Body">


<!-- <h2 class="title">Registration Form</h2> -->

<div class="container">

<?php
$fname ="{Waiting for Submission}";
$lname ="{Waiting for Submission}";
$email ="{Waiting for Submission}";
$phone ="{Waiting for Submission}";
$gender ="{Waiting for Submission}";
$birthday ="{Waiting for Submission}";
$country ="{Waiting for Submission}";
$state ="{Waiting for Submission}";
$city ="{Waiting for Submission}";
$zip ="{Waiting for Submission}";
$address ="{Waiting for Submission}";
$university ="{Waiting for Submission}";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // collect value of input field
    $fname = $_POST['fname'];
	$lname = $_POST['lname'];
	$email = $_POST['email'];
	$phone = $_POST['phone'];
	$gender =$_POST['gender'];
	$birthday = $_POST['birthday'];
	$country = $_POST['country'];
	$state = $_POST['State'];
	$city = $_POST['city'];
	$zip = $_POST['zcode'];
	$address= $_POST['address'];
	$university =$_POST['university'];
    if (empty($fname)) {
        // echo "First Name is empty";
    } else {
        // echo $fname;
    }
}
?>

<div class="col-lg-offset-1 col-md-10">
<div class="card card-5">
	<div class="card-heading">
		<h2 class="title">Submitted Form Data:</h2>
	</div>
	<div class="card-body">
	<label id="lbl_fname">First Name:</label><label id="disp_fname"><?=$fname?></label>
	<br>
	<label id="lbl_lname">Last Name:</label><label id="disp_lname"><?=$lname?></label>
	<br>
	<label id="lbl_email">Email:</label><label id="disp_email"><?=$email?></label>
	<br>
	<label id="lbl_phone">Phone:</label><label id="disp_phone"><?=$phone?></label>
	<br>
	<label id="lbl_gender">Gender:</label><label id="disp_gender"><?=$gender?></label>
	<br>
	<label id="lbl_birthday">Birthday:</label><label id="disp_birthday"><?=$birthday?></label>
	<br>
	<label id="lbl_address">Address:</label><label id="disp_address"><?=$address?></label>
	<br>
	<label id="lbl_country">Country:</label><label id="disp_country"><?=$country?></label>
	<br>
	<label id="lbl_state">State:</label><label id="disp_state"><?=$state?></label>
	<br>
	<label id="lbl_city">City:</label><label id="disp_city"><?=$city?></label>
	<br>
	<label id="lbl_zip">Zip Code:</label><label id="disp_zip"><?=$zip?></label>
	<br>
	<label id="lbl_university">
What is the best way to contact you?:</label><label id="disp_university"><?=$university?></label>
	</div>
</div>
</div>


</div>

</section>

<div id="footer">
	
	
</div>

</body></html>