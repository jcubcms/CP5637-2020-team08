$(window).scroll(function(){
  var header = $('.header'),
      scroll = $(window).scrollTop();

  if (scroll >= 80) header.addClass('header-fixed');
  else header.removeClass('header-fixed');
});

	